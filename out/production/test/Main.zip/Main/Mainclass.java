package Main;

public class Mainclass {
    public static void main(String[] args){


        IDandPasswoards iDandPasswoards = new IDandPasswoards();
        LoginPage loginPage = new LoginPage(iDandPasswoards.getLogininfo());
       // menufp m = new menufp();
      //  Menu menu = new Menu();
     //   Game game = new Game();
       // Castle castle =new Castle();
    }
}
