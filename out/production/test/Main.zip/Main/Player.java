package Main;

import java.util.Random;



public class Player {
    private Random rand;
    public int moves =0;
    private  Panel panel;
    public  int money= 1000;
    public int power;
    public  int cord;
    public  boolean inmarket = false;
    public  boolean incastle = false;
    public Player(Panel panel){
        this.panel = panel;
        rand = new Random();



    }
    public void changex(int value){
        if(moves >0){

             cord += value;

            moves --;
           loot();
           if (moves == 0) { panel.battle();
               System.out.println("battle started");}


        }
   }
    public void Dice(){
        moves = rand.nextInt(7)+1;
        System.out.println(moves);

    }
    public void loot(){
        int index = search(Map.Loott,cord);

        if(index != -1 && moves == 0){
            Map.Loott[index] = -1;
            money +=1000;

            System.out.println( money );
        }}
        public  void market(){
            int index = search(Map.Market,cord);
            if(index != -1 && moves == 0){
                inmarket = true;

            }
            else inmarket = false;
    }
    public  void Castle(){

        if(cord == 44 && moves == 0){
            incastle = true;

        }
        else incastle = false;
    }




    public static int search(int[] array , int value){
        int i ;
        for( i = 0 ; i<array.length ; i++){
            if(array[i]==value)
                return i;

        }
        return -1;
    }

}
