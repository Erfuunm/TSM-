package Main;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

public class menufp extends JFrame {

    // private Total_Map total_map ;
    JFrame frame ;

    private BufferedImage img ;
    private BufferedImage[] menu;
    private int anitick , aniindex , anispeed = 15 ;
    JButton b = new JButton();
    menufp(){
        importimage();
        loadanimation();


        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1112 , 834);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        b.setBounds(400,200,100,50);
        b.setBackground(Color.BLACK);
        b.setVisible(true);

        this.add(b);
        this.setVisible(true);

    }

    private void loadanimation() {
        menu = new BufferedImage[10];
        for (int i=0 ; i < menu.length ; i++){
            menu[i]= img.getSubimage(i*2224 , 0 , 2224 , 1668);
        }

    }
    private void importimage(){

        InputStream is = getClass().getResourceAsStream("/MENU.png");

        try {
            img = ImageIO.read(is);
        }catch (IOException e){
            throw new RuntimeException();
        }finally {
            try {
                is.close();
            }catch (IOException e){
                e.printStackTrace();
            }

        }
    }
    private void updateanimationtic() {
        anitick++ ;
        if(anitick >= anispeed){
            anitick = 0 ;
            aniindex++;
            if(aniindex >= menu.length){
                aniindex=0;
            }
        }

    }

    public void paint(Graphics g){

        updateanimationtic();
        g.drawImage(menu[aniindex] , 0 , 0 , 1112 , 834 ,  null);


        repaint();

    }


}