package Main;

import inputs.Keyboard;
import inputs.Mouse;
import inputs.Mousemo;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

public class Panel extends JPanel {
    private Random rand;
    private Map map;
    private Button up;
    private Player playerred;
    private Player playerblue;
    private int plyrsizex,plyrsizey,plyrsizex1,plyrsizey1;

    private int cordred =0,cordblue = 5,ydelta;
    private BufferedImage img;
    private BufferedImage updown;
    private BufferedImage plyred;
    private BufferedImage plyblue;
    private BufferedImage marketp;
    private BufferedImage castle;
    private BufferedImage[] background;
    private BufferedImage[] red;
    private BufferedImage[] blue;
    private BufferedImage[] market;


    Image Quest ;

    Quest questt ;
    private int anitick,aniindex,anred,anmark,anispeed= 14;
    public   int moves =0;
    public Panel(){
        rand = new Random();

        Quest = new ImageIcon("Quest.png").getImage();


        questt = new Quest();
        map = new Map();
        playerred = new Player(this);
        playerblue = new Player(this);
        playerred.cord = 44;
        playerred.money = 2000;
        playerred.power = 10;




        importimage();
        loadanimations();
        setpanelsize();
        addKeyListener(new Keyboard(this));
        addMouseListener(new Mouse(this,playerred,playerblue));
        addMouseMotionListener(new Mousemo(this));

    }

    private void loadanimations() {
        background = new BufferedImage[20];
        red = new BufferedImage[7];
        blue = new BufferedImage[7];
        market = new BufferedImage[11];


        for(int i = 0; i< background.length; i++)
        background[i] = img.getSubimage(i*2224,0,2224,1668);
        for(int i = 0; i< market.length; i++)
            market[i] = marketp.getSubimage(i*2224,0,2224,1668);
        for(int i = 0; i< red.length; i++){
            red[i] = plyred.getSubimage(i*1668,0,1668,2224);
            blue[i] = plyblue.getSubimage(i*1668,0,1668,2224);
        }
       // for(int i = 0; i< background.length; i++)
            //background[i] = img.getSubimage(i*2224,0,2224,1668);
    }

    private void importimage(){
        InputStream is = getClass().getResourceAsStream("/backg.png");
        InputStream ris = getClass().getResourceAsStream("/redsprite.png");
        InputStream bis = getClass().getResourceAsStream("/blue.png");
        InputStream jis = getClass().getResourceAsStream("/market.png");
        InputStream cas = getClass().getResourceAsStream("/castle.png");
        InputStream ud = getClass().getResourceAsStream("/updown.png");

        try {
            img = ImageIO.read(is);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try{
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            plyred = ImageIO.read(ris);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try{
                ris.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            plyblue = ImageIO.read(bis);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try{
                bis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            marketp = ImageIO.read(jis);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try{
                jis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            castle = ImageIO.read(cas);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try{
                cas.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            updown = ImageIO.read(ud);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try{
                ud.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private void setpanelsize(){
        Dimension size = new Dimension(1112,843);
        setMinimumSize(size);
        setPreferredSize(size);
        setMaximumSize(size);

    }
//    public void changex(int value){
//        if(playerred.moves >0){
//            if(Game.roundr)
//        playerred.cord += value;
//            else
//                playerblue.cord += value;
//            playerred.moves --;
//            playerred.loot();
//            playerblue.loot();
//
//            }
//
//    }
//    public void Dice(){
//        playerred.moves = rand.nextInt(7)+1;
//        System.out.println(playerred.moves);
//
//    }



   private void Plyrsize(int cord){
        switch (cord){
            case (720):
            case (680):
                plyrsizex = 52;
                plyrsizey = 70;
                plyrsizex1 = 26;
                plyrsizey1 = 35;
                break;
            case (639):
            case (607):
                plyrsizex = 51;
                plyrsizey = 69;
                plyrsizex1 = 25;
                plyrsizey1 = 35;
                break;
            case (575):
            case (546):
                plyrsizex = 50;
                plyrsizey = 68;
                plyrsizex1 = 25;
                plyrsizey1 = 35;
                break;
            case (519):
            case (494):
                plyrsizex = 49;
                plyrsizey = 67;
                plyrsizex1 = 24;
                plyrsizey1 = 35;
                break;
             case (471):
             case (448):
               plyrsizex = 48;
               plyrsizey = 66;
                 plyrsizex1 = 24;
                 plyrsizey1 = 37;
               break;}
    }

    public void battle(){
        if(playerblue.cord == playerred.cord && playerblue.moves == 0 && playerred.moves == 0){
            if(playerred.power > playerblue.power){
                playerblue.cord = 0;
                playerblue.power = 0;
                playerred.power -= playerblue.power;
                playerred.money += ((playerred.money - playerblue.money)/(playerred.money + playerblue.money))* playerblue.money;
                playerblue.money -= ((playerred.money - playerblue.money)/(playerred.money + playerblue.money))* playerblue.money;
                System.out.println("red won");

            }
            else if(playerred.power < playerblue.power && playerblue.moves == 0 && playerred.moves == 0){
                playerred.cord = 0;
                playerred.power = 0;
                playerblue.power -= playerred.power;
                playerblue.money += ((playerblue.money - playerred.money)/(playerred.money + playerblue.money))* playerred.money;
                playerred.money  -= ((playerblue.money - playerred.money)/(playerred.money + playerblue.money))* playerred.money;
                System.out.println("blue won");

            }
            else{
                playerblue.cord = 0;
                playerblue.power = 0;
                playerred.power -= playerblue.power;
                playerred.money += ((playerred.money - playerblue.money)/(playerred.money + playerblue.money))* playerblue.money;
                System.out.println("red won unjustly");}
        }
    }

    private void updateanimationtick() {
        anitick++;
        if(anitick >= anispeed) {
            anitick = 0;
            aniindex++;
            anred++;
            anmark++;
            if(aniindex >= background.length)
                aniindex = 0;
            if(anred >= red.length)
                anred = 0;
            if(anmark >= market.length -1)
                anmark = 0;
        }
    }
    public  void updategame(){
        updateanimationtick();

    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);


       g.drawImage(background[aniindex],0,0,1112,843,null);
       g.drawRect(0,0,200,200);
       g.drawString("dice placement",50,50);
        g.fillRect(0,734,100,100);



        g.drawImage(castle,0,0,1112,843,null);
        g.drawImage(updown,0,0,1112,843,null);
        for(int i=0;i<8;i++){
            if(Map.Loott[i] != -1)
        g.fillOval(map.cords[map.Loott[i]][1]-20,map.cords[map.Loott[i]][0]-20,40,40);}

   for(int i = 4; i> -1;i--){
       Plyrsize(map.cords[map.Market[i]][0] );
        g.drawImage(market[anmark] ,map.cords[map.Market[i]][1]  - (plyrsizex1+24),map.cords[map.Market[i]][0]   - (plyrsizey1+40),plyrsizex+48,plyrsizey+64,null);}
   //if(Game.roundr){
        Plyrsize(map.cords[cordred][0]);
        g.drawImage(red[anred] ,map.cords[ playerred.cord][1] - plyrsizex1,map.cords[ playerred.cord][0] - plyrsizey1,plyrsizex,plyrsizey,null);
   //else{
        g.drawImage(blue[anred] ,map.cords[ playerblue.cord][1] - plyrsizex1,map.cords[playerblue.cord][0] - plyrsizey1,plyrsizex,plyrsizey,null);

        g.drawImage(Quest , 0 ,0,240,320,null);

        //**********new******

        if(questt.quest == 1) {
            g.drawImage(questt.sword, 130, 110, 110, 120, null);
        }
        if(questt.quest == 2) {
            g.drawImage(questt.Crown, 130, 110, 110, 120, null);
        }
        if(questt.quest == 3) {
            g.drawImage(questt.ring, 130, 110, 110, 120, null);
        }
        if(questt.quest == 4) {
            g.drawImage(questt.shield, 130, 110, 110, 120, null);
        }
        if(questt.quest == 5) {
            g.drawImage(questt.row, 130, 110, 110, 120, null);
        }
        if(questt.quest == 6) {
            g.drawImage(questt.key, 130, 110, 110, 120, null);
        } if(questt.quest == 7) {
            g.drawImage(questt.scroll, 130, 110, 110, 120, null);
        } if(questt.quest == 8) {
            g.drawImage(questt.glass, 130, 110, 110, 120, null);
        }

    }


}
